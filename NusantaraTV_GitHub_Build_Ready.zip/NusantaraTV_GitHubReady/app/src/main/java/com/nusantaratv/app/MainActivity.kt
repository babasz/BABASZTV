package com.nusantaratv.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF07111F)
private val Panel = Color(0xFF142235)
private val Blue = Color(0xFF249BFF)
private val Muted = Color(0xFF9EADC2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NusantaraTvApp() }
    }
}

enum class TvSection(val label: String, val icon: ImageVector) {
    BERANDA("Beranda", Icons.Default.Home),
    LIVE_TV("Live TV", Icons.Default.Tv),
    FILM("Film", Icons.Default.Movie),
    OLAHRAGA("Olahraga", Icons.Default.SportsSoccer),
    FAVORIT("Favorit", Icons.Default.Favorite),
    PENGATURAN("Pengaturan", Icons.Default.Settings)
}

@Composable
fun NusantaraTvApp() {
    var selected by remember { mutableStateOf(TvSection.BERANDA) }
    val configuration = LocalConfiguration.current
    val wideLayout = configuration.screenWidthDp >= 800

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Blue,
            background = Navy,
            surface = Panel,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Row(
            modifier = Modifier.fillMaxSize().background(Navy).padding(if (wideLayout) 22.dp else 12.dp)
        ) {
            NavigationRail(
                selected = selected,
                onSelect = { selected = it },
                wideLayout = wideLayout
            )
            Spacer(Modifier.width(if (wideLayout) 24.dp else 12.dp))
            Column(
                modifier = Modifier.weight(1f).fillMaxHeight()
                    .verticalScroll(rememberScrollState())
            ) {
                Header()
                Spacer(Modifier.height(22.dp))
                when (selected) {
                    TvSection.BERANDA -> HomeScreen(onSelect = { selected = it })
                    TvSection.LIVE_TV -> ContentScreen("Live TV", "Pilih channel untuk mulai menonton.", listOf("RCTI", "MNCTV", "SCTV", "TV One", "ANTV", "Indosiar"))
                    TvSection.FILM -> ContentScreen("Film", "Film pilihan dan koleksi Anda.", listOf("Film Terbaru", "Drama", "Komedi", "Aksi", "Keluarga"))
                    TvSection.OLAHRAGA -> ContentScreen("Olahraga", "Siaran dan tayangan olahraga.", listOf("Sepak Bola", "Basket", "Badminton", "Balap"))
                    TvSection.FAVORIT -> ContentScreen("Favorit", "Channel dan tayangan yang Anda simpan.", listOf("Belum ada favorit"))
                    TvSection.PENGATURAN -> ContentScreen("Pengaturan", "Atur preferensi aplikasi.", listOf("Bahasa", "Kualitas Video", "Tentang Aplikasi"))
                }
            }
        }
    }
}

@Composable
private fun Header() {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Text("▣", color = Blue, fontSize = 34.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.width(10.dp))
        Column {
            Text("NUSANTARA TV", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
            Text("Semua Hiburan, Satu Aplikasi", color = Muted, fontSize = 12.sp)
        }
        Spacer(Modifier.weight(1f))
        Text("● ONLINE", color = Color(0xFF6DE0A0), fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun NavigationRail(
    selected: TvSection,
    onSelect: (TvSection) -> Unit,
    wideLayout: Boolean
) {
    Column(
        modifier = Modifier.width(if (wideLayout) 205.dp else 64.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Spacer(Modifier.height(8.dp))
        TvSection.values().forEach { section ->
            var focused by remember { mutableStateOf(false) }
            val active = selected == section
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(if (wideLayout) 54.dp else 58.dp)
                    .background(if (active || focused) Color(0xFF173F70) else Color.Transparent, RoundedCornerShape(12.dp))
                    .then(if (focused) Modifier.border(2.dp, Blue, RoundedCornerShape(12.dp)) else Modifier)
                    .onFocusChanged { focused = it.isFocused }
                    .clickable { onSelect(section) }
                    .focusable()
                    .padding(horizontal = if (wideLayout) 13.dp else 0.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = if (wideLayout) Arrangement.Start else Arrangement.Center
            ) {
                Icon(section.icon, contentDescription = section.label, tint = if (active || focused) Color.White else Muted, modifier = Modifier.size(24.dp))
                if (wideLayout) {
                    Spacer(Modifier.width(12.dp))
                    Text(section.label, color = if (active || focused) Color.White else Muted, fontWeight = if (active) FontWeight.Bold else FontWeight.Medium, fontSize = 14.sp)
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(onSelect: (TvSection) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(22.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.weight(2f).height(190.dp)
                    .background(Color(0xFF102D56), RoundedCornerShape(18.dp))
                    .padding(22.dp),
                verticalArrangement = Arrangement.Center
            ) {
                Text("SELAMAT DATANG", color = Blue, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Hiburan Indonesia\nada di sini", fontSize = 25.sp, lineHeight = 30.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(12.dp))
                Text("Pilih channel untuk mulai menjelajah.", color = Muted, fontSize = 13.sp)
            }
            Column(
                modifier = Modifier.weight(1f).height(190.dp)
                    .background(Panel, RoundedCornerShape(18.dp)).padding(18.dp),
                verticalArrangement = Arrangement.Center
            ) {
                Icon(Icons.Default.PlayCircle, null, tint = Blue, modifier = Modifier.size(34.dp))
                Spacer(Modifier.height(8.dp))
                Text("Lanjutkan\nmenonton", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("Belum ada riwayat", color = Muted, fontSize = 12.sp)
            }
        }
        Text("Channel TV Populer", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(listOf("RCTI", "MNCTV", "SCTV", "TV One", "ANTV", "Indosiar")) { channel ->
                FocusCard(title = channel, subtitle = "TV Nasional", modifier = Modifier.width(145.dp).height(108.dp))
            }
        }
        Text("Jelajahi Kategori", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(listOf(
                Triple("Live TV", Icons.Default.Tv, TvSection.LIVE_TV),
                Triple("Film", Icons.Default.Movie, TvSection.FILM),
                Triple("Olahraga", Icons.Default.SportsSoccer, TvSection.OLAHRAGA),
                Triple("Favorit", Icons.Default.Favorite, TvSection.FAVORIT)
            )) { item ->
                CategoryCard(item.first, item.second) { onSelect(item.third) }
            }
        }
        Text("Pilihan untuk Anda", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(listOf("Berita", "Drama", "Sepak Bola", "Film Keluarga")) {
                FocusCard(it, "Konten pilihan", Modifier.width(180.dp).height(100.dp))
            }
        }
        Text("Catatan: daftar ini masih contoh. Sumber streaming resmi akan ditambahkan pada tahap berikutnya.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun ContentScreen(title: String, description: String, items: List<String>) {
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text(title, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
        Text(description, color = Muted, fontSize = 14.sp)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(items) { item ->
                FocusCard(item, "Pilih untuk membuka", Modifier.width(180.dp).height(115.dp))
            }
        }
    }
}

@Composable
private fun FocusCard(title: String, subtitle: String, modifier: Modifier = Modifier) {
    var focused by remember { mutableStateOf(false) }
    Column(
        modifier = modifier
            .scale(if (focused) 1.03f else 1f)
            .background(if (focused) Color(0xFF173F70) else Panel, RoundedCornerShape(14.dp))
            .then(if (focused) Modifier.border(BorderStroke(2.dp, Blue), RoundedCornerShape(14.dp)) else Modifier)
            .onFocusChanged { focused = it.isFocused }
            .clickable { }
            .focusable()
            .padding(14.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text(title, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(5.dp))
        Text(subtitle, color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun CategoryCard(title: String, icon: ImageVector, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Column(
        modifier = Modifier.width(155.dp).height(105.dp)
            .background(if (focused) Color(0xFF173F70) else Panel, RoundedCornerShape(14.dp))
            .then(if (focused) Modifier.border(2.dp, Blue, RoundedCornerShape(14.dp)) else Modifier)
            .onFocusChanged { focused = it.isFocused }
            .clickable { onClick() }
            .focusable()
            .padding(14.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Icon(icon, null, tint = Blue, modifier = Modifier.size(27.dp))
        Spacer(Modifier.height(8.dp))
        Text(title, fontWeight = FontWeight.Bold)
    }
}
